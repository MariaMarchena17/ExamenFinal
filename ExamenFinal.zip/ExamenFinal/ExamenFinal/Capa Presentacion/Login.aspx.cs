﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExamenFinal.Presentacion
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ClsUsuario usuario = new ClsUsuario();

            usuario.Usuario = TextBox1.Text;
            usuario.Password = TextBox2.Text;

            string connectionString = ConfigurationManager.ConnectionStrings["conexion"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                int value = 0;

                connection.Open();
                string query = "SELECT COUNT(*) FROM usuarios WHERE user = @username AND password = @password";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", usuario.Usuario);
                cmd.Parameters.AddWithValue("@password", usuario.Password);

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    value = (int)command.ExecuteScalar();
                }


                if (value == 1)
                {
                    Response.Redirect("MenuPrincipal.aspx");
                }
                else
                {
                    string Message = "Usuario o contrasena erroneo, intente nevamente.";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + Message + "');", true);
                }

            }
            catch (Exception ex)
            {
                string errorMessage = ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage + "');", true);
            }
            finally
            {
                if (connection != null && connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

        }
    }
}